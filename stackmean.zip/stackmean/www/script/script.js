/*var myImage = document.querySelector('img');

fetch('http://localhost:8909/api/msg/message') 
.then(function(response) {
  return response.blob();
})
.then(function(myBlob) {
  var objectURL = URL.createObjectURL(myBlob);
    var tab = myBlob;
  //myImage.src = objectURL;
    console.log(tab);
    console.log(objectURL);
});*/

/*var a = Array.('http://localhost:8909/api/msg/message')

const msgSchema = new Array({
  title: String,
  post: String,
 
}); 

array.forEach(element => {
  
});

var b = json
*/


/*
fetch('http://localhost:8909/api/msg/message').then(function(response) {
  var contentType = response.headers.get("content-type");
  if(contentType && contentType.indexOf("application/json") !== -1) {
    return response.json().then(function(json) {
      // traitement du JSON
    });
  } else {
    console.log("Oops, nous n'avons pas du JSON!");
  }
});
*/

var url = 'http://qhttp://localhost:8909/api/msg/message'

var tab
var posts = document.querySelector('.posts')


fetch('http://localhost:8909/api/msg/message')
.then(res => res.json())
.then((out) => {
  console.log('Checkout this JSON! ', out);
  tab = out
  
  for(i = 12; i < tab["data"].length; i++){
 //posts.innerHTML += "<p>" + tab["data"][i]["title"] +"<br>" + tab["data"][i]["post"] + "</p>"
 posts.innerHTML += "<div class='innerpost'>" + tab["data"][i]["title"] +"<br>" + tab["data"][i]["post"] + "</div>"
  }
})
.catch(err => { throw err });


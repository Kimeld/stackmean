/* 
Import & config
*/
    // NodeJS
    const express = require('express');
    const msgRouter = express.Router();

    // Inner
    const checkFields = require('../../services/request.checker');
    const { createItem, readItem, updateItem, deleteItem } = require('./msg.ctrl');
//

/* 
Definition
*/
    class MsgRouterClass {
        constructor(){}

        routes(){
            // Create
            msgRouter.post( '/message', (req, res) => {

                // Error: no body present
                if (typeof req.body === 'undefined' || req.body === null) { 
                    return res.json( { msg: 'No body data provided', data: null } )
                }
                
                // Check fields in the body
                const { ok, extra, miss } = checkFields( [ 'title', 'post' ], req.body )

                //=> Error: bad fields provided
                if( !ok ) res.json( { msg: 'Bad fields provided', data: { miss: miss, extra: extra } } )
                else{
                    // Register new user
                    createItem(req.body)
                    .then( apiResponse => res.json( { msg: 'Message created', data: apiResponse } ) )
                    .catch(apiResponse => res.json( { msg: 'Message not created', data: apiResponse } ) );
                }
            })

            // Read
            msgRouter.get( '/message', (req, res) => {
                //res.json( 'test' )
                readItem('test')
                .then( apiResponse => res.json( { msg: 'Message created', data: apiResponse } ) )
                .catch(apiResponse => res.json( { msg: 'Message not created', data: apiResponse } ) );
            })

            // Update
            msgRouter.put( '/', (req, res) => {
                res.json( { msg: "Update user" } )
            })

            // Delete
            msgRouter.delete( '/', (req, res) => {
                res.json( { msg: "Delete user" } )
            })
        }

        init(){
            this.routes();
            return msgRouter;
        }
    }
//

/* 
Export
*/
    module.exports = MsgRouterClass;
//
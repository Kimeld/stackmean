/* 
Imports
*/
    // Node
    const bcrypt = require('bcrypt');
    
    // Inner
    const MsgModel = require('../../models/msg.model');
//


/* 
Méthodes CRUD
*/
    const createItem = (body) => {
        return new Promise( (resolve, reject) => {
            // Look for used email
            /*MsgModel.findOne( { title: body.title }, ( error, msg ) => {
                if(error) return reject(error) // Mongo Error
                else if(msg) return reject('User already exist')
                else {
                    // Hash user password
                    bcrypt.hash( body.password, 10 )
                    .then( hashedPassword => {
                        // Change user pasword
                        //body.password = hashedPassword;
                        
                        // Register new user
                        MsgModel.create(body)
                        .then( mongoResponse => resolve(mongoResponse) )
                        .catch( mongoResponse => reject(mongoResponse) )
                    })
                    .catch( hashError => reject(hashError) );
                }
            })*/
            MsgModel.create(body)
                        .then( mongoResponse => resolve(mongoResponse) )
                        .catch( mongoResponse => reject(mongoResponse) )
        });
    };

    const readItem = (/*ress*/) => {
        return new Promise((resolve, reject) => {
            //console.log('test')
            MsgModel.find()
            .then( mongoResponse => resolve(mongoResponse) )
            .catch( mongoResponse => reject(mongoResponse) )
        
            //do something, fetch something....
            //you guessed it, mongo queries go here.
            //db.collection('msgs').find() = ress
            //I can continue to process my result inside my promise
            /*.then(function(result){
                //another query can be called based on my result...
                return updatedResult;
            })
             //This promise may take a while...
             .then(function(result){
                 //post processing, non related mongo code...
                 //when you are ready, you can resolve the promise.
                 resolve(result);
            });*/
        })
        
            
    }

    const updateItem = () => {

    }

    const deleteItem = () => {

    }
//

/* 
Exports
*/
    module.exports = {
        createItem,
        readItem,
        updateItem,
        deleteItem
    }
//